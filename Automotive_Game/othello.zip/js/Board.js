class Board extends Othello {
    constructor() {
    }
    draw() {
        console.log('board draw');
    }
}